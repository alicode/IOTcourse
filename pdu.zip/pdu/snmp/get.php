<?php
	function get_server_info($host, $community, $objectid) {
		$a = snmpget($host, $community, $objectid);
		$tmp = explode(":", $a);

		if (count($tmp) > 1) {
			$a = trim($tmp[1]);
		}
		return $a;
	}

	$host="140.128.101.161";
	$community="public";

	for($i=1;$i<=8;$i++){
		$status = get_server_info($host,$community,".1.3.6.1.4.1.26104.3.3.3.1.4.".$i);

		// $Power = get_server_info($host,$community,".1.3.6.1.4.1.26104.3.3.3.1.9.".$i);

		$I = get_server_info($host,$community,".1.3.6.1.4.1.26104.3.3.3.1.7.".$i);

		$V = get_server_info($host,$community,".1.3.6.1.4.1.26104.3.3.3.1.6.".$i);

		$PF = get_server_info($host,$community,".1.3.6.1.4.1.26104.3.3.3.1.8.".$i);
		
		$PID=1;
		
		$arr[] = array('PID'=>$PID, 'status'=> $status, 'P'=> $PF, 'V'=> $V, 'I'=> strval($I/10));
	}
	//print_r($arr);
	echo json_encode($arr);

?>