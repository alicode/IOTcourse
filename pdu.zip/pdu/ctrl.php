<!DOCTYPE html>
<html lang="zh-Hant">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <title>Server監控管理</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
    <link href="css/bootstrap-switch.css" rel="stylesheet">
    <link href="css/pducss.css" rel="stylesheet">
  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">

        <div class="navbar-header">

          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>

          <a class="navbar-brand" href="#" id="ti">伺服器監控系統</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="http://igems.thu.edu.tw"><b>返回IGEMS</b></a></li>    
            <li class="active"><a href="ctrl.php"><b>控制台</b></a></li>
            <li><a href="#"><b>Help</b></a></li>
          </ul>         
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-2 col-md-1 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active" onclick="sidelist()"><a href="#"><b>控制台</b></a></li>
          </ul>
          
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-11 col-md-offset-1 main" style=" background-color:#ECECEC;padding-left: 0px;padding-right: 0px;" >
          <div id="show">
            <div style="z-index: 3; position: relative;background-color:rgba(255,255,255,.8);" >
              <p><h1 class="page-header" id="ti1" style=" background-color:#ECECEC;  padding-left: 20px;">檢視智慧插座</h1></p>
          </div>
        </div>

          <div id="pdu01">        
            <div style="background-color: #ffffff; padding-top: 5px;" >
              <p class="pdu_P"><font size="6" color="#000000" style="margin-left: 20px;">HPCLab PDU總功率：</font><font size="6" color="#ff0000" id="HPC01"> 0 W</font></p>
            </div> 
            <div style="background-color: #ffff00;height:10px" >

            </div>
            <div style="overflow: hidden;background-color: #00b0f0;" >
                
              <div id="B1" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T1">Socket 1</font></p>
                <div id="S1" class="sockunit" unit="1">    
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W1" >0 W</font></p>
                  <!-- <input class="sw" id="switch-1" type="checkbox" sid="1" checked> -->
                </div>
              </div>
              <div id="B2" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T2">Socket 2</font></p>
                <div id="S2" class="sockunit" unit="2">    
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W2" >0 W</font></p>
                  <!-- <input id="switch-2" type="checkbox" sid="2" checked> -->
                </div>
              </div>
              <div id="B3" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T3">Socket 3</font></p>
                <div id="S3" class="sockunit" unit="3">   
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W3" >0 W</font></p>
                  <!-- <input id="switch-3" type="checkbox" sid="3" checked> -->
                </div>
              </div>
              <div id="B4" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T4">Socket 4</font></p>
                <div id="S4" class="sockunit" unit="4"> 
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W4" >0 W</font></p> 
                  <!-- <input id="switch-4" type="checkbox" sid="4" checked> -->  
                </div>
              </div>
              <div id="B5" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T5">Socket 5</font></p>
                <div id="S5" class="sockunit" unit="5">
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W5" >0 W</font></p>
                  <!-- <input id="switch-5" type="checkbox" sid="5" checked> -->
                </div>
              </div>
              <div id="B6" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T6">Socket 6</font></p>
                <div id="S6" class="sockunit" unit="6">
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W6" >0 W</font></p>
                  <!-- <input id="switch-6" type="checkbox" sid="6" checked> -->
                </div>
              </div>
              <div id="B7" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T7">Socket 7</font></p>
                <div id="S7" class="sockunit" unit="7">  
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W7" >0 W</font></p>  
                  <!-- <input id="switch-7" type="checkbox" sid="7" checked> -->
                </div>
              </div>
              <div id="B8" class="sock">
                <p style="margin-top: 10px;"><font size="4" color="#ffffff" id="T8">Socket 8</font></p>
                <div id="S8" class="sockunit" unit="8">
                  <p style="padding-top: 110px;"><font size="4" color="#ffff00" id="W8" >0 W</font></p>    
                  <!-- <input id="switch-8" type="checkbox" sid="8" checked> -->
                </div>
              </div>

            </div>
            <div style="background-color: #ffff00;height:10px" >

            </div>
          </div>
          </div> 
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/muti/modernizr-2.0.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="js/jquery.timer.js"></script>
    <link href="css/muti/common.css" rel="stylesheet">
    <link href="css/muti/nv.d3.css" rel="stylesheet">
    <script src="js/muti/d3.v3.js"></script>
    <script src="js/muti/nv.d3.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/bootstrap-switch.js"></script>

    <script type="text/javascript">
      var flag=0;
      var thisid=0;
      $(document).ready(function(){
       // initialize all the inputs
        if($(window).width()<=1024){
          $("#ti").html("伺服器監控系統");
          $(".sidebar").hide();
          $(".main").css("margin-left","0px");
          $(".main").css("width",$(window).width()+"px");
          for(var i=1;i<=8;i++){
            $('#switch-'+i).bootstrapSwitch('labelText','SW'+i);
          }
        }
         
        $('input[type="checkbox"],[type="radio"]').not('#create-switch').not('#events-switch').bootstrapSwitch();
        var ml=($(".main").width()-960)/2;
        if(ml<0){
          ml=0;
        }
        $("#C21").css("margin-left",ml+"px");
        $("#C31").css("margin-left",ml+"px");
        $("#B1").css("margin-left",ml+"px");
        $("#SW1").css("margin-left",ml+"px");
        $("#B11").css("margin-left",ml+"px");
        $("#SW11").css("margin-left",ml+"px");
        update();
     }); 

     $(".sockunit").mouseover(function() {
        
        if(flag==0){
            $(".sock_cc").css("background-color","#A23400");
            $(".sock").css("background-color","#00b0f0");
            $("#T"+$(this).attr("unit")).css("color","#000000");
            $("#C"+$(this).attr("unit")).css("background-color","#ffff00");
            $("#B"+$(this).attr("unit")).css("background-color","#ffff00");
            $("#W"+$(this).attr("unit")).css("color","#00b0f0");
        }
        
      });

      $(".sockunit").mouseout(function() {
        //alert($(this).attr("unit"));
        if(flag==0){
            $(".sock_cc").css("background-color","#A23400");
            $(".sock").css("background-color","#00b0f0"); 
            $("#T"+$(this).attr("unit")).css("color","#FFFFFF");
            $("#C"+$(this).attr("unit")).css("background-color","#A23400");
            $("#B"+$(this).attr("unit")).css("background-color","#00b0f0");
            $("#W"+$(this).attr("unit")).css("color","#ffff00");
        }

      });

      function sidelist(){
        if($('#pdulist li').css('display')=='none'){
          $('#pdulist li').css('display','block');
        }
        else{
          $('#pdulist li').css('display','none');
        }
      }

      //TIMER 5秒
      var myVar=setInterval(function(){myTimer()},1000);
      function myTimer(){    
      update();
      }

      function update(){
          //update data
          $.ajax({
              url: "snmp/get.php", 
              type: "GET", 
              dataType: "json",
              cache: false, // don't cache the result
              success: function (JData) {
                  var NumOfJData = JData.length;
                  var P_total = 0;
                  for (var i = 0; i < NumOfJData; i++) {
                      $("#W"+(i+1)).html(JData[i]["P"]+" W");
                      if(JData[i]["P"]=="0"){
                          $("#S"+(i+1)).css('background','url("img/sockit.png") no-repeat center');
                          $("#S"+(i+1)).css('background-size','100px 100px');
                      }else{
                          $("#S"+(i+1)).css('background','url("img/sockitL.png") no-repeat center');
                          $("#S"+(i+1)).css('background-size','100px 100px');
                      }
                      P_total += parseInt(JData[i]["P"]);
                  }
                  $("#HPC01").html(P_total+" W");
              },
              error: function (xhr, status, error) {
                          //  alert("ERROR!!!");
                          //alert(xhr.status + error);
              }
          });
      }


      $(window).resize(function() { 
        var ml=($(".main").width()-960)/2;
        if(ml<0){
          ml=0;
        }
        $("#B1").css("margin-left",ml+"px");
        $("#B11").css("margin-left",ml+"px");
        $("#C21").css("margin-left",ml+"px");
        $("#C31").css("margin-left",ml+"px");
        $("#SW1").css("margin-left",ml+"px");
        if($(window).width()<=1024){
          for(var i=1;i<=8;i++){
            $('#switch-'+i).bootstrapSwitch('labelText','SW'+i);
            $('#switch-1'+i).bootstrapSwitch('labelText','SW'+i);
          }
        }else{
         for(var i=1;i<=8;i++){
          $('#switch-'+i).bootstrapSwitch('labelText','');
          $('#switch-1'+i).bootstrapSwitch('labelText','');
        }
      }
      });

    </script>  
  </body>
</html>
