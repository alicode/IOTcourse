

  var server=[]; 
  var ac=[]; 
  $.ajax({
                      url: "GetPower.php?type=S&m=ON",                      
                      type: "GET",                      
                      dataType: "json",
                      cache: false, // don't cache the result
                      
                      success: function (JData) {
                                       
                        for (var i = 0; i < JData["power"].length; i++){
                         var obj= {x:JData["day"][i],y: parseFloat(JData["power"][i])/1000};
                         server.push(obj);
                        }
                      $.ajax({
                      url: "GetPower.php?type=A&m=ON",                      
                      type: "GET",                      
                      dataType: "json",
                      cache: false, // don't cache the result
                      
                      success: function (JData) {
                                       
                        for (var i = 0; i < JData["power"].length; i++){
                         var obj= {x:JData["day"][i],y:  parseFloat(JData["power"][i])/1000};
                         ac.push(obj);
                        }
                        nv.addGraph(function() {


      var test_data = stream_layers(2,128,.1).map(function(data, i) {
    if(i==0){   
    return {
      key: '空調',      
      values: ac
    };
  }else{
     return {
      key: '伺服器',      
      values: server
    };
  }

  });
     // alert(test_data[0]["values"]);
    var chart = nv.models.multiBarChart()
      .transitionDuration(350)
      .reduceXTicks(true)   //If 'false', every single x-axis tick label will be rendered.
      .rotateLabels(0)      //Angle to rotate x-axis labels.
      .showControls(true)   //Allow user to switch between 'Grouped' and 'Stacked' mode.
      .groupSpacing(0.1)    //Distance between each group of bars.
    ;

    chart.xAxis
        .tickFormat(d3.format(',f'));

    chart.yAxis
        .tickFormat(d3.format(',.5f'));

    d3.select('#chart1 svg')
        .datum(test_data)
        .call(chart);

    nv.utils.windowResize(chart.update);
    $("#p1").hide();
    return chart;
});
                            
                      },

                      error: function (xhr, status, error) {
                          //  alert("ERROR!!!");
                          alert(xhr.status + error);
                      }
                  });
                       
                       
                        
                        
                      },

                      error: function (xhr, status, error) {
                          //  alert("ERROR!!!");
                          alert(xhr.status + error);
                      }
                  });


//Generate some nice data.
function exampleData() {
  return stream_layers(2,10+Math.random()*100,.1).map(function(data, i) {
    return {
      key: 'Stream #' + i,
      values: data
    };

  });
}


    function selY(sy){
      $("#syear").text(sy);
    }
    function selM(Ms){
      $("#p1").show();
      $("#sv1").hide();
      server=[]; 
      ac=[]; 
      $("#smou").text(Ms);
      $("#ti1").text($("#syear").text()+"年"+$("#smou").text()+"月-用電比例(千瓦/KW)");
      
      $.ajax({
                      url: "GetPower.php?type=S&m=ON&year="+$("#syear").text()+"&mo="+$("#smou").text(),                      
                      type: "GET",                      
                      dataType: "json",
                      cache: false, // don't cache the result
                      
                      success: function (JData) {
                                       
                        for (var i = 0; i < JData["power"].length; i++){
                         var obj= {x:JData["day"][i],y: parseFloat(JData["power"][i])/1000};
                         server.push(obj);
                        }
                      $.ajax({
                      url: "GetPower.php?type=A&m=ON&year="+$("#syear").text()+"&mo="+$("#smou").text(),                      
                      type: "GET",                      
                      dataType: "json",
                      cache: false, // don't cache the result
                      
                      success: function (JData) {
                                       
                        for (var i = 0; i < JData["power"].length; i++){
                         var obj= {x:JData["day"][i],y:  parseFloat(JData["power"][i])/1000};
                         ac.push(obj);
                        }
                        nv.addGraph(function() {


      var test_data = stream_layers(2,128,.1).map(function(data, i) {
    if(i==0){   
    return {
      key: '空調',      
      values: ac
    };
  }else{
     return {
      key: '伺服器',      
      values: server
    };
  }

  });
       // alert(test_data[0]["values"]);
    var chart = nv.models.multiBarChart()
      .transitionDuration(350)
      .reduceXTicks(true)   //If 'false', every single x-axis tick label will be rendered.
      .rotateLabels(0)      //Angle to rotate x-axis labels.
      .showControls(true)   //Allow user to switch between 'Grouped' and 'Stacked' mode.
      .groupSpacing(0.1)    //Distance between each group of bars.
    ;

    chart.xAxis
        .tickFormat(d3.format(',f'));

    chart.yAxis
        .tickFormat(d3.format(',.5f'));
    $("#p1").hide();
    $("#sv1").show();
    d3.select('#chart1 svg')
        .datum(test_data)
        .call(chart);

    nv.utils.windowResize(chart.update);
    
    return chart;
});
                            
                      },

                      error: function (xhr, status, error) {
                          //  alert("ERROR!!!");
                          alert(xhr.status + error);
                      }
                  });
                       
                       
                        
                        
                      },

                      error: function (xhr, status, error) {
                          //  alert("ERROR!!!");
                          alert(xhr.status + error);
                      }
                  });
    }
