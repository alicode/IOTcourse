<?php
	include_once "dblink.php";
	$sql = "SELECT `COL 1`,`COL 7`,`COL 10`,`COL 11`,`COL 15` FROM `TBL_NAME` WHERE `COL 1` LIKE '2017-02-15%' ";
	$result = mysql_query($sql) or die('MySQL query error');
	$hr1 = 0;
	$arr = array();
	$avgP = 0;
		while($row = mysql_fetch_assoc($result)){
			$hr2 = intval(substr($row['COL 1'],11,2));
			if($hr2 != $hr1){
				array_push($arr, array('hr'=>$hr1,'P'=>round($avgP/60,2)));
				$hr1 = $hr2;
				$avgP = 0;
			}
			$min = substr($row['COL 1'],14,2);
			$P = $row['COL 7'];
			$avgP += $P;
		}
		array_push($arr, array('hr'=>$hr2,'P'=>round($avgP/60,2)));
	echo json_encode($arr);
	mysql_close($Link);
?>
