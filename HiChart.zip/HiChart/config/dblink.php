<?php
	$ip = 'localhost';
	$username = 'root';
	$pwd = 'hpc123';
	$dbname = 'CSV_DB';
	$Link = mysql_connect($ip , $username , $pwd );
	mysql_query("set names utf8"); 
	mysql_select_db($dbname);
	if (!$Link) {
		die(' fail : ' . mysql_error());
	}
?>