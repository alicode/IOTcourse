<!DOCTYPE html>
<!-- saved from url=(0043)http://getbootstrap.com/examples/dashboard/ -->
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">
    <title>物聯網智慧電力系統實作課程</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link href="http://getbootstrap.com/examples/dashboard/dashboard.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="">Smart Meter</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="">Dashboard</a></li>
            <li><a href="">Settings</a></li>
            <li><a href="">Profile</a></li>
            <li><a href="">Help</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="">Overview <span class="sr-only">(current)</span></a></li>
            <li><a href="">Reports</a></li>
            <li><a href="">Analytics</a></li>
            <li><a href="">Export</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
            <div id="container_all" style="min-width: 310px; height: 400px; margin: 2% auto;"></div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script>

      $(document).ready(function() {
            chart_all();
            getData();
            alert(date);
      });
      
      function getData(){
        var daySum = 0;
        chart_all = $('#container_all').highcharts();

        //get chart data
        $.ajax({
            url: "config/getdata.php",
            type: "GET",
            dataType: "json",
            cache: false, // don't cache the result
            success: function(msg) {
                var watt = [],
                    hr = [],
                    dayAll = [];
                msg.forEach(function(entry) {
                    h = entry.hr;
                    hr.push(h);
                    if (isNaN(dayAll[parseInt(entry.hr)])) {
                      dayAll[parseInt(entry.hr)] = parseFloat(entry.P);
                      daySum += parseFloat(entry.P);
                    } else {
                      dayAll[parseInt(entry.hr)] += parseFloat(entry.P);
                      daySum += parseFloat(entry.P);
                    }
                });

                chart_all.addSeries({
                    name: "本日用電",
                    data: dayAll,
                }, true);
                chart_all.xAxis[0].setCategories(hr, true, true);
                chart_all.redraw();
            },
            error: function(xhr, status, error) {
                alert(xhr.status + error);
            }
        });
      }

      function chart_all() {
        $('#container_all').highcharts({
            chart: {
                type: 'spline'
            },
            title: {
                text: "<div style=\"font-family:Microsoft JhengHei;\">本日用電情形</div>"
            },
            xAxis: {
                labels: {
                    formatter: function() {
                        return '<span style="font-family:Microsoft JhengHei; color:black">' + this.value + '點</span>';
                    }
                }
            },
            yAxis: {
                title: {
                    text: '用電量',
                },
                labels: {
                    formatter: function() {
                        return this.value + " 瓦";
                    }
                }
            },
        });
    }
    </script>
</body>
</html>